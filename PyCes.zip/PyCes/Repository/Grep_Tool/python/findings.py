'''
	Python Findings Rulepack
'''
import os,re,remc

################################################################################################################################
# RuleSet : 1
# Level : Normal
################################################################################################################################


#Rule_META_DB
RULE_DB = {
#--Secure
"Secure Cookie Attribute Set To False":{"base_rating":4,"desc":"Secure flag is set to false in code.","regex":"(secure = false|secure = False|secure=false|secure=False|SESSION_COOKIE_SECURE = False|CSRF_COOKIE_SECURE = True|secure=None)"},

#--Http
"HttpOnly Cookie Attribute Set To False":{"base_rating":4,"desc":"HttpOnly flag is possibly set to false in code.","regex":"(HttpOnly=False|HttpOnly: False|SESSION_COOKIE_HTTPONLY = False|httpOnly=false|CSRF_COOKIE_HTTPONLY = False|httponly=False)"},

#--Certificate
"Insecure Certificate Validation":{"base_rating":4,"desc":"Certificate validation is not implemented properly in the code.","regex":"(disable_ssl_certificate_validation=True|_create_unverified_context|_create_unverified_https_context|_create_default_https_context)"},

#--Debug
"Debug Enabled":{"base_rating":4,"desc":"DEBUG set to True in code, Verify.","regex":"(DEBUG = True|debug=True|debug = True|DEBUG=True|app.debug = True|app.run|DEBUG=true|TEMPLATE_DEBUG = True)"},

#--Csrf
"Csrf Check Disabled":{"base_rating":4,"desc":"CSRF is exempted, thereby prone to CSRF attacks.","regex":"(csrf_exempt|csrf_exempt = True|csrf_except|CSRF_ENABLED = True|import csrf_exempt)"},

#--clickjacking
"Clickjacking Protection Disabled":{"base_rating":4,"desc":"Clickjacking protection seems to be disabled,possible security issue.","regex":"(X_FRAME_OPTIONS = 'Allow'|xframe_options_allow|ok_to_load_in_a_frame)"},

#--browser
"Session Not Invalidated After Browser Closure":{"base_rating":4,"desc":"Session not terminated even after the browser is closed.","regex":"(SESSION_EXPIRE_AT_BROWSER_CLOSE = False)"},

#--Use_of_print_function
"Use of print_stack function":{"base_rating":4,"desc":"Stack being printed,Check if it  is accessible by user.","regex":"(print_stack|traceback.print_tb|traceback.print_exception|traceback.print_exc|traceback.print_stack|traceback.print_last|traceback.extract_tb|traceback.extract_stack|traceback.tb_lineno)"},

#--Session_timeout_set_to_permanent
"Session Timeout Set To Permanent":{"base_rating":4,"desc":"Session time-out is set to Permanent, potential security issue.","regex":"(session.permanent = True)"},

#--HTTP_scheme_is_being_used
 "HTTP Scheme Is Being Used":{"base_rating":4,"desc":"Application seems to be using HTTP","regex":"(scheme='http')"},

#--Insecure_hashers
"Insecure Hash Functions":{"base_rating":4,"desc":"Insecure hash functions are imported by code","regex":"(django.contrib.auth.hashers.UnsaltedMD5PasswordHasher|django.contrib.auth.hashers.MD5PasswordHashe|django.contrib.auth.hashers.UnsaltedSHA1PasswordHasher|django.contrib.auth.hashers.SHA1PasswordHasher|digest_method|hashlib.md5)"},

#--Insecure_session
"Insecure Session Management":{"base_rating":4,"desc":"Import of insecure session management engine","regex":"(django.contrib.sessions.backends.signed_cookies)"},

#--weak_input_val
# "Weak Input Validation":{"base_rating":4,"desc":"Inputs may be used in code without proper validation.","regex":"(cherrypy.request.body.read|request.get|request.POST.get)"},

#--secure_redirect_set_to_false
"Secure Redirect Set To False":{"base_rating":4,"desc":"Secure redirection appears to be set to false.","regex":"(SECURE_SSL_REDIRECT = False)"},

#--server_side_injection
"Server Side Template Injection":{"base_rating":4,"desc":"Values injected in template can alter the server response if input values are not enclosed in {{ }}. Check if input values are properly sanitized.","regex":"(render_template_string|render_template)"},

#--pickle
"Pickle Library Used":{"base_rating":4,"desc":"Pickle library appears to be in use, possible security issue.","regex":"(pickle.loads|pickle.dump|pickle.dumps|pickle.load|pickle.Unpickler|cPickle.loads|cPickle.load|cPickle.Unpickler)"},

#--eval
# "Eval Function Used":{"base_rating":4,"desc":"Use of possibly insecure function - consider using safer functions.","regex":"(pickle.loads|pickle.dump|pickle.dumps|pickle.load|pickle.Unpickler|cPickle.loads|cPickle.load|cPickle.Unpickler)"},

#--eval
"Reference to vulnerable algorithms":{"base_rating":4,"desc":"Reference to vulnerable algorithms","regex":"(md5|MD5|3DES|blowfish|SHA-0|SHA-1)"},

}
#Add keys as name param for all findings.
for fk in RULE_DB.keys():
	RULE_DB[fk]["finding_name"] = fk

#Master Rule List - we can enable or disable tests here.
def run_rules(mk,module_entry):
	findings_db = {}
	
	
	findings_db.update(re_detect(mk,module_entry,RULE_DB["Secure Cookie Attribute Set To False"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["HttpOnly Cookie Attribute Set To False"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Insecure Certificate Validation"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Debug Enabled"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Csrf Check Disabled"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Session Not Invalidated After Browser Closure"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Use of print_stack function"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Session Timeout Set To Permanent"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["HTTP Scheme Is Being Used"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Insecure Hash Functions"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Insecure Session Management"]))

	# findings_db.update(re_detect(mk,module_entry,RULE_DB["Weak Input Validation"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Secure Redirect Set To False"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Clickjacking Protection Disabled"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Server Side Template Injection"]))

	# findings_db.update(re_detect(mk,module_entry,RULE_DB["Eval Function Used"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Reference to vulnerable algorithms"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB["Pickle Library Used"]))




	#Warning - Don't Enable This Rule!!!
	#imprt(mk,module_entry,RULE_DB["Useless_Import"])

	return findings_db

################################################################################################################################

################################################################################################################################
# RuleSet : 2
# Level : High
################################################################################################################################


#Rule_META_DB
RULE_DB2 = {
#--Secure
"Secure Cookie Attribute Set To False":{"base_rating":4,"desc":"Secure flag is set to false in code.","regex":"(secure = false|secure = False|secure=false|secure=False|SESSION_COOKIE_SECURE = False|CSRF_COOKIE_SECURE = True|secure=None)"},

#--Http
"HttpOnly Cookie Attribute Set To False":{"base_rating":4,"desc":"HttpOnly flag is possibly set to false in code.","regex":"(HttpOnly=False|HttpOnly: False|SESSION_COOKIE_HTTPONLY = False|httpOnly=false|CSRF_COOKIE_HTTPONLY = False|httponly=False)"},

#--Certificate
"Insecure Certificate Validation":{"base_rating":4,"desc":"Certificate validation is not implemented properly in the code.","regex":"(disable_ssl_certificate_validation=True|_create_unverified_context|_create_unverified_https_context|_create_default_https_context)"},

#--Debug
"Debug Enabled":{"base_rating":4,"desc":"DEBUG set to True in code, Verify.","regex":"(DEBUG = True|debug=True|debug = True|DEBUG=True|app.debug = True|app.run|DEBUG=true|TEMPLATE_DEBUG = True)"},

#--Csrf
"Csrf Check Disabled":{"base_rating":4,"desc":"CSRF is exempted, thereby prone to CSRF attacks.","regex":"(csrf_exempt|csrf_exempt = True|csrf_except|CSRF_ENABLED = True|import csrf_exempt)"},

#--clickjacking
"Clickjacking Protection Disabled":{"base_rating":4,"desc":"Clickjacking protection seems to be disabled,possible security issue.","regex":"(X_FRAME_OPTIONS = 'Allow'|xframe_options_allow|ok_to_load_in_a_frame)"},

#--browser
"Session Not Invalidated After Browser Closure":{"base_rating":4,"desc":"Session not terminated even after the browser is closed.","regex":"(SESSION_EXPIRE_AT_BROWSER_CLOSE = False)"},

#--Use_of_print_function
"Use of print_stack function":{"base_rating":4,"desc":"Stack being printed,Check if it  is accessible by user.","regex":"(print_stack|traceback.print_tb|traceback.print_exception|traceback.print_exc|traceback.print_stack|traceback.print_last|traceback.extract_tb|traceback.extract_stack|traceback.tb_lineno)"},

#--Session_timeout_set_to_permanent
"Session Timeout Set To Permanent":{"base_rating":4,"desc":"Session time-out is set to Permanent, potential security issue.","regex":"(session.permanent = True)"},

#--HTTP_scheme_is_being_used
 "HTTP Scheme Is Being Used":{"base_rating":4,"desc":"Application seems to be using HTTP","regex":"(scheme='http')"},

#--Insecure_hashers
"Insecure Hash Functions":{"base_rating":4,"desc":"Insecure hash functions are imported by code","regex":"(django.contrib.auth.hashers.UnsaltedMD5PasswordHasher|django.contrib.auth.hashers.MD5PasswordHashe|django.contrib.auth.hashers.UnsaltedSHA1PasswordHasher|django.contrib.auth.hashers.SHA1PasswordHasher|digest_method|hashlib.md5)"},

#--Insecure_session
"Insecure Session Management":{"base_rating":4,"desc":"Import of insecure session management engine","regex":"(django.contrib.sessions.backends.signed_cookies)"},

#--weak_input_val
"Weak Input Validation":{"base_rating":4,"desc":"Inputs may be used in code without proper validation.","regex":"(cherrypy.request.body.read|request.get|request.POST.get)"},

#--secure_redirect_set_to_false
"Secure Redirect Set To False":{"base_rating":4,"desc":"Secure redirection appears to be set to false.","regex":"(SECURE_SSL_REDIRECT = False)"},

#--server_side_injection
"Server Side Template Injection":{"base_rating":4,"desc":"Values injected in template can alter the server response if input values are not enclosed in {{ }}. Check if input values are properly sanitized.","regex":"(render_template_string|render_template)"},

#--pickle
"Pickle Library Used":{"base_rating":4,"desc":"Pickle library appears to be in use, possible security issue.","regex":"(pickle.loads|pickle.dump|pickle.dumps|pickle.load|pickle.Unpickler|cPickle.loads|cPickle.load|cPickle.Unpickler)"},

#--eval
"Eval Function Used":{"base_rating":4,"desc":"Use of possibly insecure function - consider using safer functions.","regex":"(eval|exec)"},

#--eval
"Reference to vulnerable algorithms":{"base_rating":4,"desc":"Reference to vulnerable algorithms","regex":"(md5|MD5|3DES|blowfish|SHA-0|SHA-1)"},

}
#Add keys as name param for all findings.
for fk in RULE_DB2.keys():
	RULE_DB2[fk]["finding_name"] = fk

#Master Rule List - we can enable or disable tests here.
def run_rules2(mk,module_entry):
	findings_db = {}
	
	
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Secure Cookie Attribute Set To False"]))

	findings_db.update(re_detect(mk,module_entry,RULE_DB2["HttpOnly Cookie Attribute Set To False"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Insecure Certificate Validation"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Debug Enabled"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Csrf Check Disabled"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Session Not Invalidated After Browser Closure"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Use of print_stack function"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Session Timeout Set To Permanent"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["HTTP Scheme Is Being Used"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Insecure Hash Functions"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Insecure Session Management"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Weak Input Validation"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Secure Redirect Set To False"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Clickjacking Protection Disabled"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Server Side Template Injection"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Eval Function Used"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Reference to vulnerable algorithms"]))
 
	findings_db.update(re_detect(mk,module_entry,RULE_DB2["Pickle Library Used"]))




	#Warning - Don't Enable This Rule!!!
	#imprt(mk,module_entry,RULE_DB["Useless_Import"])

	return findings_db

################################################################################################################################

#===HARDCODED RULES===z
#Regex matching - the less sophisticated rules.
def re_detect(mk,module_entry,rule_entry):
	findings_db = {}
	if(len(re.findall(rule_entry["regex"],module_entry["file_data"])) > 0):
		lines = module_entry["file_data"].split("\n")
		for ln in range(0,len(lines)):
			res = re.findall(rule_entry["regex"],lines[ln])
			if(len(res) > 0):
				be = {"import_list":module_entry["import_list"],"finding_name":rule_entry["finding_name"],"base_rating":rule_entry["base_rating"],"desc":rule_entry["desc"]}
				be["finding_lineno"] = ln + 1
				be["srcfile"] = mk
				be["finding_snippet"] = lines[ln]
				#print("%s %s:%d || %s" % (be["finding_name"],be["srcfile"],be["finding_lineno"],lines[ln]))
				findings_db[be["finding_name"]+be["srcfile"]+str(be["finding_lineno"])] = be
	return findings_db

#When we want to weed out commented results.
def re_detect2(mk,module_entry,rule_entry):
	findings_db = {}
	#Remove Comments and Docstrings. Exception passing if corrupt pyc data.
	try: 
		clean_data = remc.remove_comments_and_docstrings(module_entry["file_data"])
	except:
		clean_data = module_entry['file_data']
	if(len(re.findall(rule_entry["regex"],clean_data)) > 0):
		lines = clean_data.split("\n")
		for ln in range(0,len(lines)):
			if("#" in lines[ln]):
				continue
			res = re.findall(rule_entry["regex"],lines[ln])
			if(len(res) > 0):
				be = {"import_list":module_entry["import_list"],"finding_name":rule_entry["finding_name"],"base_rating":rule_entry["base_rating"],"desc":rule_entry["desc"]}
				be["finding_lineno"] = ln + 1
				#Get original line number from src with comments if available.
				olines = module_entry["file_data"].split("\n")
				for j in range(0,len(olines)):
					if(lines[ln] == olines[j]):
						be["finding_lineno"] = j + 1
				
				
				be["srcfile"] = mk
				be["finding_snippet"] = lines[ln]
				#print("%s %s:%d || %s" % (be["finding_name"],be["srcfile"],be["finding_lineno"],be["finding_snippet"]))
				findings_db[be["finding_name"]+be["srcfile"]+str(be["finding_lineno"])] = be
			
	
	return findings_db				

#When we want to weed out commented results and regex.
def re_detect3(mk,module_entry,rule_entry):
	findings_db = {}
	#Remove Comments and Docstrings. Exception passing if corrupt pyc data.
	try: 
		clean_data = remc.remove_comments_and_docstrings(module_entry["file_data"])
	except:
		clean_data = module_entry['file_data']
	if(len(re.findall(rule_entry["regex"],clean_data)) > 0):
		lines = clean_data.split("\n")
		for ln in range(0,len(lines)):
			if("re.compile(" in lines[ln]):
				continue
			
			res = re.findall(rule_entry["regex"],lines[ln])
			if(len(res) > 0):
				be = {"import_list":module_entry["import_list"],"finding_name":rule_entry["finding_name"],"base_rating":rule_entry["base_rating"],"desc":rule_entry["desc"]}
				be["finding_lineno"] = ln + 1
				be["srcfile"] = mk
				be["finding_snippet"] = lines[ln]
				#print("%s %s:%d || %s" % (be["finding_name"],be["srcfile"],be["finding_lineno"],lines[ln]))
				findings_db[be["finding_name"]+be["srcfile"]+str(be["finding_lineno"])] = be
	return findings_db
#Regular regex, but also checks if a module is loaded.
def re_detect_wimp(mk,module_entry,rule_entry,mod_loaded):
	findings_db = {}
	if(not mod_loaded in module_entry["import_list"]):
		return findings_db
	if(len(re.findall(rule_entry["regex"],module_entry["file_data"])) > 0):
		lines = module_entry["file_data"].split("\n")
		for ln in range(0,len(lines)):
			if("#" in lines[ln]):
				continue
			res = re.findall(rule_entry["regex"],lines[ln])
			if(len(res) > 0):
				be = {"import_list":module_entry["import_list"],"finding_name":rule_entry["finding_name"],"base_rating":rule_entry["base_rating"],"desc":rule_entry["desc"]}
				be["finding_lineno"] = ln + 1
				be["srcfile"] = mk
				be["finding_snippet"] = lines[ln]
				#print("%s %s:%d || %s" % (be["finding_name"],be["srcfile"],be["finding_lineno"],lines[ln]))
				findings_db[be["finding_name"]+be["srcfile"]+str(be["finding_lineno"])] = be
	return findings_db
	
